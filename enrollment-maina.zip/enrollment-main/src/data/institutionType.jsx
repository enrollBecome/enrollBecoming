import React from 'react'

const InstitutionType = [
    "High School","College","University","Post-Secondary Diploma/Certificate"
]

export default InstitutionType