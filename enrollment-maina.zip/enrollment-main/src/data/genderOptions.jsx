

const GenderOptions = [
    "Male",
    "Female",
    "Undeclared",
    "Unspecified"
]

export default GenderOptions