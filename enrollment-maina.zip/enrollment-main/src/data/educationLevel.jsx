import React from 'react'

const EducationLevel = [
    "Elementary School",
    "High School",
    "College Diploma/Certifciate",
    "Bachelor's Degree",
    "Ph.D Degree",
    "Post-Doctorate Degree"
]

export default EducationLevel