import React from 'react'

const YesNo =["Yes","No"];

export default YesNo