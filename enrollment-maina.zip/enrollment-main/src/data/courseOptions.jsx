

const CourseOptions = [
    "12-Month Trauma Recovery Program",
   
]

export default CourseOptions