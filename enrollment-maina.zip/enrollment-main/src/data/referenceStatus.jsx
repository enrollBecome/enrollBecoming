

const RefrenceStatus =["Approve","Decline"];

export default RefrenceStatus