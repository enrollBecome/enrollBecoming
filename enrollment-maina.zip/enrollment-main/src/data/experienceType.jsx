import React from 'react'

const ExperienceType = [
    "Employment","Volunteer","Community / Social","Community / Clinical"
]

export default ExperienceType