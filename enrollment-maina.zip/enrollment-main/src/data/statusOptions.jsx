import React from 'react'

const StatusOptions = ["Approved","Submitted","Paid","In Progress"]

export default StatusOptions