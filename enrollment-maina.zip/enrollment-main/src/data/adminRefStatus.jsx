import React from 'react'

const AdminRefStatus = [
    "Pending", "Approve","Decline"
]
export default AdminRefStatus