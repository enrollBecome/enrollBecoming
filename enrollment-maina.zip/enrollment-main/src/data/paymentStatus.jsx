import React from 'react'

const PaymentStatus = ["Unpaid","Initial Payment Completed","Term 1 Payment Completed","Term 2 Payment Completed","Term 3 Payment Completed"];

export default PaymentStatus