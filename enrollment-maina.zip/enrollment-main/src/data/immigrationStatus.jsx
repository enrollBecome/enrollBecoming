import React from 'react'

const ImmigrationStatus = [
    "Canadian Citizen",
    "Permanent Resident",
    "Refugee",
    "International Student",
    "Visitor"

]

export default ImmigrationStatus