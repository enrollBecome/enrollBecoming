

const TermOptions = [
    "Fall","Winter","Spring"
]

export default TermOptions