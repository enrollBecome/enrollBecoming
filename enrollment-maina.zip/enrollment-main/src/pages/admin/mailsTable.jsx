import React from 'react'

const MailsTable = () => {
  return (
    <div>MailsTable</div>
  )
}

export default MailsTable