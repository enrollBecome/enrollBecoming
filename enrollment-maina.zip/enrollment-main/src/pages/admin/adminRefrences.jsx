import React from 'react'

const AdminReferences = () => {
  return (
    <div>AdminReferences</div>
  )
}

export default AdminReferences