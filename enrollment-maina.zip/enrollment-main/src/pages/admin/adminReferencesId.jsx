import React from 'react'

const AdminReferencesId = () => {
  return (
    <div>AdminReferencesId</div>
  )
}

export default AdminReferencesId