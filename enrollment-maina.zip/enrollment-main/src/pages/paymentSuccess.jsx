import React from 'react'

const PaymentSuccess = () => {
    
  return (
    <div>PaymentSuccess</div>
  )
}

export default PaymentSuccess