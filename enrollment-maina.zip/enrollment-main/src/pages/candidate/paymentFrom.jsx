import React from 'react'

const PaymentForm = () => {
  return (
    <div>PaymentForm</div>
  )
}

export default PaymentForm