import React from 'react'

const MyApplication = () => {
  return (
    <div>MyApplication
n
    </div>
  )
}

export default MyApplication